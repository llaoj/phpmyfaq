# Version

This endpoint returns the phpMyFAQ version number as string.

**URL** : `/api/v2.0/version`

**Method** : `GET`

**Auth required** : NO

## Success Response

**Code** : `200 OK`

**Content example**

```json
"3.0.0"
```
