# Language

This endpoint returns the default language as language code.

**URL** : `/api/v2.0/language`

**Method** : `GET`

**Auth required** : NO

## Success Response

**Code** : `200 OK`

**Content example**

```json
"de"
```
