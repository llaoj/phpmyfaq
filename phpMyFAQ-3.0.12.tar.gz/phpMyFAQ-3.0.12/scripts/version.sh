#!/bin/sh
if [ "x${PMF_VERSION}" = "x" ]; then
    PMF_VERSION="3.0.12"
fi
